<?php
include 'db.php';

$output = "";

if (isset($_POST['query'])) {
    $search = $conn->real_escape_string($_POST['query']);

    $sql = "SELECT * FROM destinations WHERE title LIKE '%$search%' OR description LIKE '%$search%'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $output .= '
            <div class="destination-card large">
                <div class="card-image">
                    <img src="uploads/'.$row['image'].'" alt="'.$row['title'].'">
                    <div class="card-overlay">
                        <h3>'.$row['title'].'</h3>
                        <p>'.$row['description'].'</p>
                    </div>
                </div>
            </div>
            ';
        }
    } else {
        $output = '<p>No destinations found.</p>';
    }

    echo $output;
}
?>
