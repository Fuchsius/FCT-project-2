<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title> Destinations</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="container">
    <h1>Destinations</h1>

    <div class="search-bar">
        <input type="text" id="search" placeholder="Search...">
        <button type="submit"><i class="fas fa-search"></i></button>
    </div>

    <form action="upload.php" method="post" enctype="multipart/form-data">
        <input type="text" name="title" placeholder="Title" required><br>
        <textarea name="description" placeholder="Description" required></textarea><br>
        <input type="file" name="image" accept="image/*" required><br>
        <button type="submit" name="submit">Add Destination</button>
    </form>

    <div class="destinations-grid">
        <?php
        $sql = "SELECT * FROM destinations";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '
                <div class="destination-card large">
                    <div class="card-image">
                        <img src="uploads/'.$row['image'].'" alt="'.$row['title'].'">
                        <div class="card-overlay">
                            <h3>'.$row['title'].'</h3>
                            <p>'.$row['description'].'</p>
                        </div>
                    </div>
                </div>
                ';
            }
        }
        ?>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function(){
    $('#search').on('keyup', function(){
        var query = $(this).val();
        $.ajax({
            url: "search.php",
            method: "POST",
            data: {query:query},
            success:function(data){
                $('.destinations-grid').html(data);
            }
        });
    });
});
</script>
</body>
</html>
