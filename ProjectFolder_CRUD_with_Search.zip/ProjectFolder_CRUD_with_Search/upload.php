<?php
include 'db.php';

if (isset($_POST['submit'])) {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $image = $_FILES['image']['name'];
    $target = "uploads/" . basename($image);

    $sql = "INSERT INTO destinations (title, description, image) VALUES ('$title', '$description', '$image')";

    if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
        if ($conn->query($sql) === TRUE) {
            header("Location: index.php");
            exit();
        } else {
            echo "Database Error: " . $conn->error;
        }
    } else {
        echo "Failed to upload image.";
    }
}
?>
